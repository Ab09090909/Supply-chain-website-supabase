-- ============================================================================
-- DIAGNOSTIC: Check that storage RLS policies are correctly applied
-- ----------------------------------------------------------------------------
-- Run this in Supabase SQL Editor when uploads fail with "row-level security"
-- or "Unauthorized" errors. It will tell you exactly what's missing.
--
-- This script is READ-ONLY — it does not modify anything. After running,
-- check the output of each query to find the gap.
-- ============================================================================

-- 1. Check that the storage schema exists
select '1. Storage schema exists' as check_name,
       case when exists (select 1 from information_schema.schemata where schema_name = 'storage')
            then '✅ yes' else '❌ NO — Supabase Storage is not enabled' end as status;

-- 2. Check that the product-images bucket exists
select '2. product-images bucket exists' as check_name,
       case when exists (select 1 from storage.buckets where id = 'product-images')
            then '✅ yes (public=' || (select public::text from storage.buckets where id = 'product-images') || ')'
            else '❌ NO — run migration_v2.sql to create the bucket'
       end as status;

-- 3. List all storage policies on storage.objects
select '3. Storage policies on storage.objects' as check_name,
       policyname,
       cmd as operation,
       roles,
       substring(qual::text, 1, 60) || case when length(qual::text) > 60 then '...' end as using_clause,
       substring(with_check::text, 1, 60) || case when length(with_check::text) > 60 then '...' end as with_check_clause
from pg_policies
where schemaname = 'storage' and tablename = 'objects'
order by policyname, cmd;

-- 4. Check that RLS is enabled on storage.objects
select '4. RLS enabled on storage.objects' as check_name,
       case when relrowsecurity
            then '✅ yes' else '❌ NO — RLS is disabled, all access is denied' end as status
from pg_class
where relname = 'objects' and relnamespace = (select oid from pg_namespace where nspname = 'storage');

-- 5. Check the grant on storage.objects (defensive — Supabase usually does this)
select '5. Privileges on storage.objects' as check_name,
       grantee,
       privilege_type
from information_schema.role_table_grants
where table_schema = 'storage' and table_name = 'objects'
order by grantee, privilege_type;

-- 6. Test: simulate an INSERT as a hypothetical authenticated user
--    (Replace '00000000-0000-0000-0000-000000000000' with your real user id
--     if you want to test the policy for a specific user.)
do $$
declare
  test_uid uuid := '00000000-0000-0000-0000-000000000000';
  can_insert boolean;
begin
  -- This simulates: "as user test_uid, can I insert into product-images?"
  perform set_config('request.jwt.claim.sub', test_uid::text, true);
  perform set_config('request.jwt.claim.role', 'authenticated', true);

  begin
    -- This is a SELECT, not an actual INSERT, so it doesn't write anything.
    -- It just checks whether the WITH CHECK would pass.
    select exists(
      select 1
      where bucket_id = 'product-images'
        and auth.uid() is not null
    ) into can_insert;

    raise notice '6. Policy check for test user %: %', test_uid,
      case when can_insert then '✅ policy would pass' else '❌ policy would fail' end;
  end;
end $$;

-- 7. Show the final verdict
select '=== SUMMARY ===' as section;
select
  (select count(*) from storage.buckets where id = 'product-images') as product_images_bucket_count,
  (select count(*) from pg_policies where schemaname = 'storage' and tablename = 'objects' and cmd = 'INSERT') as insert_policies_count,
  (select relrowsecurity from pg_class where relname = 'objects' and relnamespace = 'storage'::regnamespace) as rls_enabled;

-- If insert_policies_count is 0, the policies were never created.
-- If product_images_bucket_count is 0, the bucket was never created.
-- If rls_enabled is 'f', RLS is disabled (which actually means ALL access is denied).
